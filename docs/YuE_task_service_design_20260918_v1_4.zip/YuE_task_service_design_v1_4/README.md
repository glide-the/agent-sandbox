# 任务服务、模型执行与Claude plugin Skill设计交付 v1.4

**2026-09-18｜本包为设计规格，未实现或部署MCP endpoint。**

本版新增 `comfy_mcp_task → comfy_mcp_processor → comfy-mcp endpoint`。原YuE2／SheetSage2独立任务与环境不变。调用方继续使用通用上传、任务提交及两个只读结果接口。

## 本次重点

跨机器上传必须真正传送字节，包括工作流JSON和媒体输入；不能发送调用方本地路径代替上传。后端生成的文件需收集到Runner任务目录，完成校验后才能通过`task_id + result_source_name`交付。MCP消息不默认内嵌大文件。

首读[10_MCP_endpoint与上传下载兼容设计](10_MCP_endpoint与上传下载兼容设计.md)。新增时序图见[05_业务时序图](05_业务时序图.md)第4节；既有三份YuE图继续保留。第7节仍为独立Skill封装文档。

## 交付索引

| 文档或目录 | 内容 |
|---|---|
| 01_技术设计稿.md | 既有源码、模型、任务与资源设计；新增MCP适配引用 |
| 02_文件级实施清单.md | 两仓库改造位置及兼容影响；均为待实施 |
| 03_验证计划与实际检查.md | V01–V18及M01–M14验证边界 |
| 04_符合性审查与决策.md | 原目标及MCP增量审查 |
| 05_业务时序图.md、diagrams/ | 三份原流程和一份新增MCP文件交接流程 |
| 07_Claude_plugin_Skill封装设计.md | 保留原Skill步骤，模型执行经任务服务 |
| 08_模型环境与任务绑定修订.md | 先前两个模型绑定规则，继续适用 |
| 09_通用上传与任务输出资源契约修订.md | Runner资产与输出寻址；MCP后端交接补充 |
| 10_MCP_endpoint与上传下载兼容设计.md | comfy-mcp证据、协议、上传下载、安全、生命周期和实施验证 |
| examples/mcp/ | 拟议Task及endpoint profile的JSON Schema和静态样例 |
| examples/sandbox.mcp.example.yaml | 独立Comfy任务、Processor、解释器及endpoint绑定 |
| evidence/ | 历史基线、本次补读来源与静态检查结果 |
| 阅读版.html | 离线合并阅读，Mermaid以源码展示 |

## 范围与验证

本期不新增应用接入、播放器、独立客户端产品或通用MCP代理。新增endpoint位于comfy-mcp服务端；模型执行仍由既有Runner管理。对用户的Runner接口数量不变；未共享文件系统时，后端按需提供两个内部通用文件入口，详见第10文档。

本包不含业务源码改造、模型权重、环境安装、实际模型音频、服务凭据或可安装插件。仅做静态Schema／YAML／引用／文件摘要／ZIP检查。未运行真实HTTP、MCP、Task、GPU、插件或Mermaid渲染器验证。

解压后运行`python tools/verify_delivery.py`核对文件SHA256；该命令仅验证文档包完整性。新增静态契约检查可运行`python tools/check_mcp_design.py`，需要jsonschema和PyYAML，不调用网络或模型。
