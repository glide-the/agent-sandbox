#!/usr/bin/env python3
"""Validate design examples only; this does not exercise a live MCP/HTTP service."""
from __future__ import annotations
import copy
import hashlib
import json
import re
from pathlib import Path
import jsonschema
import yaml

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / 'examples' / 'mcp'

def load(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))

def main() -> int:
    report = {'scope': 'static design contracts only', 'positive_cases': 0,
              'negative_cases': 0, 'configuration_checks': 0,
              'diagram_structure_checks': 0, 'runtime_tests_run': False, 'errors': []}
    def check(condition: bool, message: str):
        if not condition:
            report['errors'].append(message)
    task_schema = load(EXAMPLES / 'submission.schema.json')
    tool_schema = load(EXAMPLES / 'tool-call.schema.json')
    for s in [task_schema, tool_schema]:
        jsonschema.Draft202012Validator.check_schema(s)
    task = load(EXAMPLES / '01_comfy_workflow.submit.json')
    tool_paths = sorted(EXAMPLES.glob('0[2-5]_*.tool.json'))
    for obj, sch in [(task, task_schema)] + [(load(p), tool_schema) for p in tool_paths]:
        jsonschema.validate(obj, sch)
        report['positive_cases'] += 1
    negatives = []
    for key, value in [('endpoint', 'http://127.0.0.1/mcp'), ('environment', '/tmp/env'),
                       ('workflow_path', '/etc/passwd'), ('command', 'sh'), ('out_dir','/tmp/out')]:
        obj=copy.deepcopy(task);obj['payload'][key]=value;negatives.append((obj,task_schema,key))
    obj=copy.deepcopy(task);obj['parameter']['task_name']='yue2_task';negatives.append((obj,task_schema,'wrong task'))
    obj=copy.deepcopy(task);obj['payload']['workflow_asset_id']='../asset';negatives.append((obj,task_schema,'unsafe asset'))
    obj=copy.deepcopy(task);obj['parameter']['reset']=True;negatives.append((obj,task_schema,'reset'))
    for name,args,label in [
        ('upload_file',{'paths':['/etc/passwd']},'remote arbitrary path'),
        ('upload_file',{'asset_ids':[]},'empty uploads'),
        ('fetch_outputs',{'prompt_id':'prompt_demo','out_dir':'/root'},'remote arbitrary output'),
        ('fetch_outputs',{'prompt_id':'prompt_demo','inline_images':True},'remote inline bytes'),
        ('job',{'action':'queue','prompt_id':'prompt_demo'},'global queue'),
        ('job',{'action':'wait','prompt_id':'prompt_demo','timeout_seconds':6000},'unbounded wait'),
        ('job',{'action':'status','prompt_id':'prompt_demo','timeout_seconds':60},'ignored arg'),
        ('launch_comfyui',{},'admin tool')]:
        negatives.append(({'name':name,'arguments':args},tool_schema,label))
    run=load(EXAMPLES/'03_run_workflow.tool.json');run['arguments']['wait']=True
    negatives.append((run,tool_schema,'synchronous generation'))
    for obj, sch, label in negatives:
        errors=list(jsonschema.Draft202012Validator(sch).iter_errors(obj))
        check(bool(errors),f'Negative case unexpectedly accepted: {label}')
        report['negative_cases'] += 1
    # Retain the old native-task schema regression at the document-contract level.
    oldschema=load(ROOT/'examples/submission.schema.json')
    for p in sorted((ROOT/'examples').glob('0[1-5]_*.submit.json')):
        jsonschema.validate(load(p), oldschema)
        report['positive_cases'] += 1
    cfg=yaml.safe_load((ROOT/'examples/sandbox.mcp.example.yaml').read_text())
    pcfg=cfg['preprocess'][0]['comfy_mcp_processor']
    tcfg=cfg['tasks'][0]['comfy_mcp_task']
    checks=[pcfg['environment']=='/root/comfy-mcp-client-env',
            pcfg['endpoint']['url'].endswith('/mcp'),
            tcfg['preprocess'][0]['comfy']['processor']=='comfy_mcp_processor',
            set(pcfg['allowed_tools'])=={'upload_file','run_workflow','job','fetch_outputs'},
            pcfg['file_transfer']['mode']=='http',
            pcfg['file_transfer']['download_attempts']==3]
    for i,c in enumerate(checks): check(c,f'MCP config check {i} failed')
    report['configuration_checks'] += len(checks)
    native=yaml.safe_load((ROOT/'examples/sandbox.music.example.yaml').read_text())
    envs=[list(i.values())[0]['environment'] for i in native['preprocess']]
    check(envs==['/root/yue-env','/root/sheetsage2-env'],'Native environment binding changed')
    report['configuration_checks'] += 1
    fixture=(EXAMPLES/'transfer-fixture.txt').read_bytes()
    for item in [load(EXAMPLES/'06_backend_files.response.json')['files'][0],
                 load(EXAMPLES/'07_runner_result.response.json')['data']['result']['artifacts'][0]]:
        check(item['size_bytes']==len(fixture),'Fixture size mismatch')
        check(item['sha256']==hashlib.sha256(fixture).hexdigest(),'Fixture SHA mismatch')
        report['positive_cases']+=1
    # Structure-only: do not call this a Mermaid parser or renderer test.
    for p in (ROOT/'diagrams').glob('*.mmd'):
        text=p.read_text(); declared=set(re.findall(r'^\s*(?:participant|actor)\s+(\w+)',text,re.M))
        check('SK' in declared,f'Expected single Skill actor in {p.name}')
        check('IM与Claude Agent' not in text and '服务型Skill客户端' not in text,f'Removed actor in {p.name}')
        stack=[]
        for line in text.splitlines():
            word=line.strip().split(' ',1)[0]
            if word in {'alt','opt','loop','par','critical','break','rect'}: stack.append(word)
            elif word=='end':
                if not stack: report['errors'].append(f'Unmatched end: {p.name}')
                else: stack.pop()
            match=re.match(r'^\s*(\w+)(?:--?>[>x)]?|--?>>)(\w+)\s*:',line)
            if match:
                check(set(match.groups())<=declared,f'Unknown actor in {p.name}: {line.strip()}')
        check(not stack,f'Unclosed blocks: {p.name}: {stack}')
        report['diagram_structure_checks'] += 1
    report['passed']=not report['errors']
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0 if report['passed'] else 1

if __name__=='__main__':
    raise SystemExit(main())
