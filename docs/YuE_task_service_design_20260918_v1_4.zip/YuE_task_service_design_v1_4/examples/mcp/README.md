# MCP与文件传输静态样例 v1.4

这些字段是第10文档的拟议契约；不是comfy-mcp当前main已支持的调用。01是Runner提交；02–05是逻辑tools/call参数，不是完整JSON-RPC/HTTP报文，外层版本元数据由锁定SDK生成。不同协议版本不可混用握手或header。

Runner资产先经过POST /runner/upload；跨机器后端资产由Processor通过POST /files上传得到。两者ID不混用。示例节点12、输入image和Comfy文件引用只展示字段形状，必须以实际工作流/节点和comfy upload返回值验证，未运行该工作流。

06和07大小与SHA256对应本目录transfer-fixture.txt，仅用于文件传输契约静态检查，无模型内容。06是拟议后端文件描述，07是Runner最终投影；最终调用方只需task_id与result_source_name。

comfy-http.profile.example.json及上级sandbox.mcp.example.yaml都是部署规格，当前代码没有实现其新增字段加载。不要直接复制运行后宣称支持。共享模式需要验证真实挂载；后端/file接口仅对授权任务服务开放。
