# v1.4 本轮补读来源

固定comfy-mcp提交：b35f92af0a0a76aa40b620949880eab4c6bf82ec。

读取pyproject.toml、src/comfy_mcp/cli.py、target.py和server.py中的MCPServer、入口、upload_file、fetch_outputs、job及相关执行上下文。fetch_outputs可核对server.py约5820行附近；旧工具paths/out_dir指向MCP服务机器；CLI提交记录保存在该机器。未声称通读并验证所有一万余行工具实现。

agent-sandbox补读固定8eb568e4fe3b333a31469a60bff2693493a520c8的pyproject.toml，其FastAPI/Pydantic/Python约束是隔离MCP SDK运行环境的依据；未运行依赖求解，不声称已证实不可共存。

官方MCP 2026-07-28 Streamable HTTP、2025-11-25工具结果、Python SDK ASGI说明已在线核对。支持范围仍需所选SDK实测。源链接及各结论对应见第10文档C01–C06、P01–P03。

本轮未改业务仓库；无AutoDL、模型、真实HTTP/MCP协议或ComfyUI运行验证。引用旧设计的基线与源码结论时继续保留其历史范围，不将旧测试改写为本轮通过。
