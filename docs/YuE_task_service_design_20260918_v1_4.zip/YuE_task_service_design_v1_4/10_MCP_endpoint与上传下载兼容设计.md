# MCP endpoint 与上传下载兼容设计

**版本：1.4｜修订日期：2026-09-18｜交付：设计规格，非已实现服务。**

## 1. 接入位置与范围

本次将“兼容 MCP endpoint”落实在现有任务架构的**执行适配层**：新增 `comfy_mcp_task`，固定绑定 `comfy_mcp_processor`，由 Processor 调用配置中的 `comfy-mcp` endpoint。Claude plugin Skill 继续使用同一组 Runner 接口。原 YuE、SheetSage2 的任务、环境和业务步骤不变。

```text
Claude plugin Skill
  → agent-sandbox /runner/submit
  → ComfyMcpTask / ComfyMcpProcessor
  → comfy-mcp /mcp
  → comfy-cli → ComfyUI
  → 收集实际文件 → Runner 任务资源清单
```

这条新增链路用于执行已有 ComfyUI 工作流，不声称 comfy-mcp 原生支持 YuE 的 `SongRequest`，也不要求把 YuE 改造成 ComfyUI 节点。YuE 的模型采样仍走 `yue2_task`；只有明确选择 Comfy 工作流的任务走新增绑定。

**不新增第二套任务队列，不把 MCP 工具调用的完成等同于模型任务完成。** `/mcp` 位于 comfy-mcp 的远程服务端；本轮不再给 agent-sandbox 叠加一套对外 MCP 镜像。后者是另一个入口需求，不是兼容模型执行 endpoint 的前提。

对调用方，文件链路保持：`POST /runner/upload → POST /runner/submit → GET /runner/result → GET /runner/result_source`。MCP 用于调用工具及返回少量结构化结果，音频、图片、视频及其他大文件通过 HTTP 字节传输或经过验证的共享文件系统交接。

## 2. 源码事实与不能直接复用的部分

本轮读取的 comfy-mcp 为 `main@b35f92af0a0a76aa40b620949880eab4c6bf82ec`；以下结论以该提交为准，不声称覆盖全部工具或以后提交。[C01]

| 路径／符号 | 已读事实 | 本次处理 |
|---|---|---|
| `pyproject.toml` | 包版本0.10.0；Python>=3.10；`mcp>=2,<3`、`pydantic>=2`；comfy-cli另行安装 | 固定实际 SDK／CLI 版本验证，不把“2.x”当协议兼容证明。[C02] |
| `server.py::mcp / main`、`cli.py::_usage` | `MCPServer` 注册工具；入口为stdio，CLI当前只处理帮助／版本 | 保留stdio；新增经过实际参数解析的HTTP启动选项，不能只在文档写`--transport`。[C03][C04] |
| `server.py::upload_file` | 接收`paths: list[str]`，调用`comfy upload`；paths属于MCP服务所在机器 | 远程profile改用已登记的后端资产引用，不开放任意服务器路径。[C03] |
| `server.py::fetch_outputs` | 接收`prompt_id/out_dir/url_only/inline_images`；`comfy download`写MCP服务所在机器 | 远程profile由服务端分配目录并提供文件描述；Runner另行流式归档，不返回“已下载到用户电脑”。[C03] |
| `server.py::fetch_outputs`、`target.py` | 输出下载依赖提交机器的CLI状态文件；其中保存远端输出URL | 固定endpoint与持久CLI工作目录；不能切另一实例只凭prompt_id就继续下载。[C03][C05] |
| `target.py::_TARGET_AWARE_SUBCOMMANDS` | run/run-template/jobs/upload共同转发远端目标；download不以同样方式转发 | 输入上传、执行、状态与结果必须归属同一目标；冻结目标配置。[C05] |
| `target.py::_comfy_target` | COMFYUI_URL不能带HTTPS、反向代理路径、查询参数；这些值会拒绝而非降级 | MCP外部HTTPS地址与ComfyUI内部地址分开配置；不得将`https://…/mcp`填入COMFYUI_URL。[C05] |
| `server.py::job` | 有status/wait/watch/error/cancel/queue；同步分支有线程卸载 | 本期只启用执行所需动作；等待有预算，取消需核对具体任务语义。[C03] |
| agent-sandbox `pyproject.toml` | Python>=3.10,<3.12、FastAPI0.109.2、Pydantic~=2.5.0 | 不直接升级主服务依赖；MCP SDK桥接使用单独解释器，主服务只管理受控子进程。[C06] |

comfy-mcp 当前面向本机信任边界；把stdio改成HTTP不等于资源授权已经存在。尤其不得将安装节点、下载模型、启动／停止服务、任意workflow_path和任意out_dir一并公开。

## 3. 环境、配置与任务绑定

新增绑定为：`comfy_mcp_task → comfy_mcp_processor → MCP调用解释器 → 配置的远程endpoint`。Processor的`environment`仍只表示**本机虚拟环境根目录**；远端comfy-mcp及ComfyUI的实际环境由其部署配置决定，不能通过一个本机路径声称切换了远端解释器。

| 环境 | 拟议目录 | 作用 |
|---|---|---|
| 既有YuE环境 | `/root/yue-env` | YuE2生成，不变 |
| 既有SheetSage2环境 | `/root/sheetsage2-env` | 转录，不变 |
| 新MCP调用环境 | `/root/comfy-mcp-client-env` | 运行受控MCP桥接脚本，包含锁定SDK，无GPU推理依赖 |
| endpoint服务环境 | `/root/comfy-mcp-env` | comfy-mcp和所选comfy-cli；目录为拟议值 |
| ComfyUI运行环境 | 由实际ComfyUI部署指定 | 模型与节点依赖；不假设与endpoint环境相同 |

新增客户端解释器用于避免把新SDK、ASGI和依赖升级扩散到旧任务服务；当前没有执行依赖求解，因此不将潜在版本冲突写成已经证实的故障。桥接脚本是Processor内部实现，不是新的客户端产品或服务。

配置片段见`examples/sandbox.mcp.example.yaml`。它合并到现有列表而非覆盖原配置。endpoint地址、后端文件服务地址、工具白名单、允许的Comfy工作流、凭据来源、输出根目录均为服务端配置。客户端不得透传endpoint、任意tool名称、Python路径或命令。

## 4. MCP endpoint 兼容规则

### 4.1 保留stdio，新增受控HTTP profile

comfy-mcp新增`streamable-http`启动模式；默认stdio的工具名和参数保持兼容。HTTP模式独立注册`runner` profile，仅暴露`run_workflow`、`job`必要动作、`upload_file`、`fetch_outputs`。这些工具名称沿用上游，**远程安全参数模型为拟新增契约，不是现有源码已支持的调用方式**。

协议层使用官方SDK，不手写一套JSON-RPC路由器。HTTP ASGI应用使用SDK提供的应用入口，并明确启动／关闭生命周期；子应用挂载位置与内部path只能组成一个`/mcp`，避免`/mcp/mcp`。官方SDK提供现有ASGI应用挂载方式。[P02]

### 4.2 版本必须明确

| profile | 设计目标 | 验收条件 |
|---|---|---|
| stdio既有模式 | 保留已使用的本地调用 | 原stdio回归；不把HTTP日志写入协议stdout |
| HTTP 2025-11-25兼容模式 | 作为兼容测试目标 | SDK真实完成initialize及tools/list、tools/call；会话行为遵循该版本，不借用业务task_id |
| HTTP 2026-07-28模式 | 当前规范对应的目标 | 锁定SDK确实支持该版本后启用；逐请求元数据／header一致，单独测试 |
| 旧HTTP+SSE双endpoint模式 | 本期不增加 | 不宣称兼容所有历史transport |

2026-07-28规范取消独立GET消息流与协议会话；HTTP请求头与JSON-RPC元数据必须匹配。这些规则不能和2025版握手／session规则拼接使用。新版GET/DELETE `/mcp`的405不影响正常GET文件接口。具体HTTP协议版本由所选SDK负责；未通过对应互操作测试时不标记支持。[P01]

TLS、合法Origin／Host、认证、请求体上限和工具授权都必须开启。MCP连接标识和JSON-RPC request id不具有资源授权或业务去重含义。外部MCP token不能原样转发给ComfyUI或其他目标；后端调用使用其独立服务凭据。

## 5. 上传改造：必须跨过真实文件边界

### 5.1 对外仍是通用Runner上传

`POST /runner/upload`继续接收`file,user_id`，流式暂存、计算真实`sha256/size_bytes`，完整写入后返回`asset_id`。目录为`uploads/<canonical_user_id>/<asset_id>/…`。通用上传不加载模型、不解压、不清目录、不覆盖同名资产。

后续`/runner/submit`只引用资产。`comfy_mcp_task`还需要**工作流JSON本身的资产**，不能只改图像上传，却让`run_workflow(workflow_path)`继续读取一个不存在的调用方路径。音频、ABC、工作流JSON和模型权重分别处理：前几类可作为受控业务输入；权重与节点安装仍属于部署准备。

### 5.2 两种文件交接模式

| 模式 | 输入交接 | 输出交接 | 前提 |
|---|---|---|---|
| `shared_fs` | 从同一用户已登记资产解析受控路径，再调用本机文件型工具 | CLI输出写任务暂存目录，检查后登记到Runner | 两进程确实共享允许根目录；用同一文件SHA256验证，不能只因同名路径就假定共享 |
| `http` | Runner把字节上传到endpoint配套文件入口，取得后端asset_id，再调用MCP工具 | endpoint提供只读文件描述，Runner流式取回并登记 | 跨机器默认采用；认证、归属、完整性和清理范围一致 |

**本版同时定义跨机器模式，不把“挂到HTTP”当作文件已经可传。** `shared_fs`可作为单台AutoDL的最小部署；它不是跨机器模式失败后的静默回退。

### 5.3 远程服务端最小文件桥接

在comfy-mcp同一HTTP应用中拟新增两个通用文件入口，仅对授权Runner开放：

| endpoint侧路径 | 用途 | 与Runner接口的关系 |
|---|---|---|
| `POST /files` | multipart字节上传，返回`asset_id,sha256,size_bytes` | Processor内部调用；不替代对用户的`/runner/upload` |
| `GET /files/{file_id}` | 只读已登记的后端输出文件 | Processor收集产物；最终用户仍用`/runner/result_source` |

这两个入口只补足未共享文件系统的传输缺口，没有第二套任务提交／查询API。共享文件系统部署可禁用它们。这里的`asset_id/file_id`属于后端命名空间，Processor内部记录为`backend_asset_id/backend_file_id`；不能与Runner自己的asset_id混用，也不暴露新的输出ID要求给最终调用方。

后端上传完整后，MCP `upload_file(asset_ids=[…])`从本地资产记录解析路径，再执行原有`comfy upload`。工具必须返回Comfy实际接受的文件引用，包含真实名称／子目录等可用字段；按返回值绑定工作流节点输入，不能自己猜文件名。若当前CLI不支持某种音频／ABC输入，应在消费前拒绝，不以“通用上传成功”表示节点能处理。

工作流JSON作为已上传文件解析，不通过Comfy图像上传接口传递；`workflow_asset_id`和媒体input bindings分别处理。bindings只修改已验证节点的指定输入字段，不全局替换JSON中每个相同字符串。工作流必须符合服务端批准的结构／摘要与可变字段策略，不能开放任意文件读取节点。`comfy_file_ref`即使来自一次工具返回，也必须反查同一用户的上传登记，不能直接把其他用户的Comfy文件名绑定进工作流。

### 5.4 隔离与失败

两个服务都以已认证主体校验user_id，登记每个资产的归属和完整性。服务间凭据按原用户映射或经验证的服务授权绑定，不接受工具参数自报owner即获得权限。共享Comfy输入目录使用带用户／资产前缀的唯一名称，默认禁止overwrite。

限制单文件和批次总量；大小以实际接收字节为准，超过上限中止并清理临时文件。SHA256边读边算，不将音频全部读入内存或编码到MCP消息。单独限制文件名、路径、符号链接及嵌入NUL。上传失败时不调用模型；部分成功逐项记录，不把整个批次标为成功。

## 6. 下载改造：归档后才成为Runner资源

### 6.1 `fetch_outputs`必须适配

原工具的`out_dir`是MCP机器路径，不是用户目录；`url_only`得到的后端URL也不自动是最终可交付地址。远程profile改为`fetch_outputs(prompt_id)`：服务端核对prompt归属，使用自己分配的目录调用原CLI收集文件，返回下列结构化描述；禁止调用方指定任意out_dir，默认不内联图片、音频或视频。[C03]

```json
{
  "prompt_id": "backend_prompt_demo",
  "files": [{
    "file_id": "backend_file_demo",
    "filename": "image_0001.png",
    "media_type": "image/png",
    "size_bytes": 2048,
    "sha256": "<服务端实际计算的64位十六进制摘要>",
    "download_path": "/files/backend_file_demo"
  }]
}
```

该例是拟议字段形状，文件与大小不是实测产物。优先用`structuredContent`和明确output schema；保留少量文本摘要。资源链接仅说明位置，不等于接收方已经下载文件。[P03]

### 6.2 Runner的产物收集

Processor将后端描述与配置的文件服务base URL组合；拒绝任意外部origin、协议降级、跳转及伪造路径，不让模型输出变成任意服务器请求入口。后端凭据只用于对应后端，不能随重定向发送到第三方。

每个文件流式写入本任务`.part`，检查实际字节数、上限、SHA256和适当的格式属性，完成后原子改名并登记`result_source_name`。保持原始文件名作为展示元数据，不拿它充当可覆盖文件路径。资源名由Task确定且任务内唯一；多节点同名产物使用不同名称，不用数组索引漂移覆盖旧记录。

随后，现有`GET /runner/result`返回资源清单；`GET /runner/result_source`按`task_id + result_source_name`读取Runner控制的文件。服务器绝对路径、临时后端文件ID和未经代理的`/view`地址不作为最终用户下载要求。

**模型完成、后端文件可读取、Runner归档完成是三个不同事实。** 只有归档并登记成功才设`delivery_status=ready`。文件收集失败保留后端prompt_id及清单，以相同任务重取；不重新run_workflow。已归档文件的用户下载失败，只重取现有GET。

provider自身从ComfyUI收集文件时，同样检查状态记录中的源URL是否属于配置目标；该校验不能只放在Runner一侧。未经验证的跨域地址不得交给comfy download自动拉取。

### 6.3 只读和恢复边界

`GET /files/{file_id}`和两个Runner GET均只读，不在GET中运行CLI收集、搬文件、重新登记或采样。后端`fetch_outputs`是已有工具的收集动作，可缓存已验证文件；它不是新增公开重发布API。

首版断线下载采用有限次数整文件重试，`.part`校验后再完成；只有两端支持一致ETag及Range时才启用字节续传，不将Range写成现有接口已实现。原生输出损坏或后端CLI状态丢失时返回明确错误，不能无限重试或重新生成掩盖。

### 6.4 保留与清理

后端资产及输出使用独立不可变ID。重复fetch_outputs取得同一job的已验证文件记录；未完成的CLI下载只留在暂存目录，不提前登记。输入在所有引用任务结束前不可清理；输出在配置保留期内可重取。清理跳过活动上传、活动job和正在传输的文件，失败文件保留诊断宽限期后删除。

共享模式和HTTP模式各自检查读取期间的文件占用；未验证跨进程引用协调之前，禁止仅按目录时间删除。原生CLI状态目录持久化并绑定endpoint实例，不能随着一次MCP连接关闭而删除。后端与Runner的保留期分别配置，后端保留期至少覆盖最大任务时长和结果归档重试预算；到期后明确返回过期，不自动重采样。

## 7. Task、MCP request 与后端job标识

| 标识 | 来源及作用 | 禁止混同 |
|---|---|---|
| Runner `task_id` | 现有任务服务分配，外部查询和文件归属 | 不等于prompt_id或JSON-RPC id |
| MCP request id | SDK分配的一次协议请求标识 | 不做生成去重或文件归属 |
| 后端`prompt_id` | Comfy执行提交返回 | 与endpoint身份、固定CLI项目、owner及task_id一起保存 |
| Runner `asset_id` | 通用上传返回 | 不直接当远端文件名 |
| 后端资产／文件ID | endpoint传输登记生成 | 只在该endpoint命名空间使用 |

原公开任务白名单、权限和持久记录需显式纳入comfy_mcp_task；只添加Processor注册而仍让旧入口拒绝该Task，不算完成接入。请求按task_name选择对应严格模型，原YuE Schema无需接受Comfy字段。

新增Task按“输入准备→MCP异步提交→等待后端终态→收集产物→登记结果”运行。`run_workflow(wait=false)`只表示后端接受，Task仍在执行，不能先报告end。协议错误、MCP `isError`、原工具的error/unsupported字段、后端job失败和文件收集失败分别解释；成功查询到失败job不等于模型成功。未知的后端状态不能按成功处理；记录原始状态和可解释映射，禁止臆造百分比。

对每个提交意图保存`execution_key`，在endpoint的受控profile记录`owner + execution_key → prompt_id`。同键同规范化请求返回原后端job，同键不同请求拒绝。该映射是本次拟新增，原生comfy-mcp没有被本轮证明提供业务幂等。

若后端已接受而响应／映射写入丢失，进入`submission_unknown`错误阶段并暂停该执行域的新派发，人工核查队列或服务侧持久记录；不声称exactly-once，也不盲目重提。恢复须回到保存的endpoint和CLI项目目录。普通网络错误不能让配置切到其他服务器。

## 8. 超时、取消与GPU占用

任务服务沿用现有生命周期和最大并发控制。MCP每次请求、后端等待、文件传输和整个业务Task分别设置有限deadline。状态查询失败可在预算内重试，生成提交重试须遵守上节去重和不确定状态规则。

本地桥接进程退出、MCP连接断开或SSE请求取消，**不证明远端GPU任务停止**。后端接受后，需依据其prompt_id调用实际支持的任务取消，再确认终态；若接口只能全局中断队列，不向普通用户开放。无法确认终止时保留资源占用标记并暂停该执行域的派发，不假报“已停止”。新版HTTP连接关闭取消的是该MCP请求，与独立业务job的生命周期应分开。[P01]

ComfyUI通常是常驻模型进程，不能沿YuE子进程退出逻辑推断模型显存已释放。跨YuE／Comfy共用GPU时，验证正确目标的空闲状态和卸载完成，再切换；原`free_memory`表示请求而非完成，部分资源工具不跟随远端目标，需要相应检查。[C03][C05]

## 9. 文件级实施清单

以下均是后续实施规格。未修改任何仓库、安装SDK或发布endpoint。

| 仓库 | 现有／拟新增路径 | 改动及必要性 |
|---|---|---|
| agent-sandbox | 已有`sandbox.yaml`、processors/tasks注册文件 | 新增comfy绑定，沿用注册机制；保留两个YuE相关任务 |
| agent-sandbox | 拟新增`sandbox/tasks/comfy_mcp_task.py` | Task参数、固定Processor、后端job关联与终态规则 |
| agent-sandbox | 拟新增`sandbox/processors/comfy_mcp_processor.py` | MCP调用生命周期、输入绑定、收集产物；不注册任意工具执行Task |
| agent-sandbox | 拟新增`sandbox/processors/mcp_bridge.py` | 在environment选定解释器中运行SDK；受控JSON契约、有限等待和协议错误转换 |
| agent-sandbox | 拟议`runner_assets.py`及既有runner资源路由 | 上传资产解析复用；新增后端传输映射；仍按task_id/result_source_name返回文件 |
| agent-sandbox | 拟新增`sandbox/processors/mcp_file_transfer.py` | shared_fs/http两种受控交接、流式校验、清理与下载重试 |
| comfy-mcp | 已有`src/comfy_mcp/server.py` | 提取可复用引擎调用；保留stdio旧Schema，remote profile不接受任意paths/out_dir；管理job归属 |
| comfy-mcp | 已有`src/comfy_mcp/cli.py` | 真实解析transport/profile/host/port配置，保持默认stdio及帮助兼容 |
| comfy-mcp | 拟新增`src/comfy_mcp/http_endpoint.py` | SDK ASGI入口、认证、profile注册与生命周期；非自建协议栈 |
| comfy-mcp | 拟新增`src/comfy_mcp/file_transfer.py` | POST /files、只读GET /files/{file_id}、资产登记、目录隔离和流式传输 |
| comfy-mcp | 已有`src/comfy_mcp/target.py` | 冻结部署目标；不把MCP地址和ComfyUI目标混用；不在并发请求中修改全局环境变量 |
| 两仓库 | 拟新增相邻MCP与文件测试 | 见下方M01–M14；不复制本机信任假设到HTTP |
| Claude plugin | `SKILL.md`与服务参考文档，设计文件 | 同一上传／任务／结果机制；不要新增应用层或独立客户端产品 |

## 10. 可执行验证计划与验收条件

新增测试文件属于实施阶段；本次只生成规格和静态样例。拟实施后的命令：

```bash
# agent-sandbox 工作区；测试文件需按本设计实现
python -m pytest -q tests/mcp_endpoint -m 'not live_backend'
# comfy-mcp 工作区；保留全量旧stdio回归，再执行新profile测试
python -m pytest -q tests
# 专用环境执行跨机器真实测试，不能用模拟结果替代
python -m pytest -q tests/mcp_endpoint -m live_backend
```

| 编号 | 测试 | 通过标准 |
|---|---|---|
| M01 | 两仓库基线及依赖记录 | 记录实际HEAD、SDK、CLI、ComfyUI版本；旧服务依赖未被无说明升级 |
| M02 | environment与endpoint绑定 | YAML选中对应解释器；错误环境／地址明确失败；不退回本机默认 |
| M03 | stdio／HTTP profile | 旧stdio回归；HTTP只暴露白名单，真实tools/list与调用成功 |
| M04 | 协议版本矩阵 | 分别实测2025-11-25及2026-07-28；未通过版本不宣传支持；header错配拒绝 |
| M05 | 输入来自另一台机器 | 调用方路径在后端不存在仍可上传、绑定、执行；无共享目录依赖 |
| M06 | 用户隔离、同名与并发上传 | 不越权、不覆盖；上传中断不产生可引用完整资产 |
| M07 | 大文件与完整性 | 超额、伪造长度、SHA不符、符号链接、NUL均拒绝；内存不随文件体积线性增长 |
| M08 | 工作流文件和媒体绑定 | workflow_asset与输入媒体均可用；使用实际Comfy返回文件引用；不忽略未知绑定 |
| M09 | 后端接受与Task终态 | 返回prompt_id不结束Task；后端完成后才收集；全部归档完成再ready |
| M10 | 三段下载故障 | 后端→endpoint、endpoint→Runner、Runner→调用方分别断线；重取不增加生成次数 |
| M11 | 响应丢失与重启 | 保存endpoint/project/prompt_id；同execution_key不盲目重采样；未知状态明确报告 |
| M12 | URL与工具权限 | 非允许origin、凭据跨域、任意paths/out_dir、全局停机和安装工具均拒绝 |
| M13 | 超时／取消与GPU | 关闭本地桥接不误报远端停止；按job核对取消，无法确认时暂停该执行域 |
| M14 | 全链路与原任务回归 | 上传→submit→MCP→文件归档→两个GET完成；YuE原有生成／转录／编辑契约保持 |

测试必须包括HTTP与真实MCP客户端，不以直接调用Python函数冒充协议兼容。使用小型Comfy工作流冒烟后，再验证目标媒体格式和体积；可下载不等于内容质量合格。

## 11. 删减审查与当前结论

保留：一个ComfyMcpTask、一个固定endpoint Processor、必要的SDK运行环境、跨机器文件桥接和少量job归属记录。它们分别解决任务边界、协议调用、依赖隔离、真实字节传输和结果恢复。

不做：通用动态MCP代理平台、任意tool执行入口、二次排队系统、全部Comfy工具公网化、自动下载模型／安装节点、Base64大文件通道、默认签名URL系统，以及将YuE迁移为ComfyUI节点。

**当前仅完成设计与静态规格；两仓库代码改造、真实MCP互操作、上传下载压测和模型实测均未完成。** 本版补充了v1.3未覆盖的MCP执行endpoint；“不默认新增MCP包装层”的旧结论在此明确需求范围内调整，其他业务设计不扩张。

## 来源

[C01]: https://github.com/glide-the/comfy-mcp/tree/b35f92af0a0a76aa40b620949880eab4c6bf82ec
[C02]: https://github.com/glide-the/comfy-mcp/blob/b35f92af0a0a76aa40b620949880eab4c6bf82ec/pyproject.toml
[C03]: https://github.com/glide-the/comfy-mcp/blob/b35f92af0a0a76aa40b620949880eab4c6bf82ec/src/comfy_mcp/server.py
[C04]: https://github.com/glide-the/comfy-mcp/blob/b35f92af0a0a76aa40b620949880eab4c6bf82ec/src/comfy_mcp/cli.py
[C05]: https://github.com/glide-the/comfy-mcp/blob/b35f92af0a0a76aa40b620949880eab4c6bf82ec/src/comfy_mcp/target.py
[C06]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/pyproject.toml
[P01]: https://modelcontextprotocol.io/specification/2026-07-28/basic/transports/streamable-http
[P02]: https://py.sdk.modelcontextprotocol.io/run/asgi/
[P03]: https://modelcontextprotocol.io/specification/2025-11-25/server/tools
