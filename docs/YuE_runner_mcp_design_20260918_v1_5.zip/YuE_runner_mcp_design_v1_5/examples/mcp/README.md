# 四个Runner工具的MCP设计示例

本目录是协议契约样例，不是服务器实现。`tools.list.json`中只有四个工具；`01`至`04`是对应的tools/call请求。提交保留原parameter/payload；幂等键是额外的协议映射参数。

`transfer-fixture.abc`仅供文件字节校验，非模型产物；两个文件结果示例使用其实际字节数和SHA256。inline结果的Base64可还原该文件；link结果明确bytes_included=false，示例.invalid地址不可访问。

调用侧负责实际编码、解码和文件保存。大文件走原HTTP流，不在MCP消息中无界内联。Schema中的contentEncoding不会自动验证Base64，因此检查脚本另外严格解码。

继承的音乐Schema仅用于验证音乐部署样例，不能代替实际Runner按部署授权开放的任务注册表。认证来自传输上下文；填写user_id不代表获得该身份。
