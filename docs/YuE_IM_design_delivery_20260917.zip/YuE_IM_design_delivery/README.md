# YuE_IM_design_delivery

这是**设计交付包，不是已实现/已部署的业务系统或可安装插件**。

阅读 [交付清单](00_交付清单与阅读说明.md)、[完整设计稿](01_技术设计稿.md) 或离线 `阅读版.html`。实现位置、验证命令和审查分别见02、03、04。`diagrams`提供三份Mermaid源码。

解压后运行 `python tools/verify_delivery.py` 检查本包SHA256；此命令不进行GPU、服务或IM测试。
