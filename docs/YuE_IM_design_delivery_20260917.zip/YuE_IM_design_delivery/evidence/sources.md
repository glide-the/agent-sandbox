# 源码与官方资料索引

固定到所列commit。以下列出读取位置与判断，不是运行测试结果；本包未复制完整仓库或模型权重。

## S01
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox.yaml

读取对象：`preprocess / tasks / bootstrap`

preprocess 是具体处理器配置的列表；tasks 通过 processor 与 processor_name 绑定；配置中的 max_ongoing_tasks=10。

## S02
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/processors/__init__.py

读取对象：`load_preprocess / processors_cache`

registry.get_processor_class(cfg.name).from_config(cfg)，实例缓存按配置键索引。

## S03
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/tasks/__init__.py

读取对象：`load_task / get_task`

任务工厂从 YAML 创建实例；新增类型需导入以触发注册。

## S04
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/server/model/flow_data.py

读取对象：`PayLoad / RunnerParameter`

真实外壳为 parameter + payload；reset 默认 true、user_multi_task 默认 false；payload 允许 Dict。

## S05
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/server/servlet/runner.py

读取对象：`submit_async / result_async / result_source_async / post_task_update_async`

提交和查询、资源读取及内部状态同步已存在；提交前 prepare 与 Worker prepare 都会执行；资源接口直接读取结果中的路径。

## S06
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/start/core.py

读取对象：`Speaker.preparation_runner / WebSpeaker.listen / sync_state`

prepare→dispatch→end；Worker semaphore=100；同步 HTTP 出现在异步函数；终态同步异常有无限重试风险。

## S07
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/tasks/base_task.py

读取对象：`Runner / BaseTask.report_progress / SandboxTaskAbstract.save_task_write`

统一进度钩子和四路径结果；save_task_write 仅检查 result_path 存在并发 save_write。

## S08
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/processors/base_processor.py

读取对象：`BaseProcessor.from_config / init_paths`

不存在通用 environment 解释器选择；init_paths 默认抛异常。

## S09
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/processors/sanbox_started.py

读取对象：`SandboxToVoice / run_evaluate_process`

旧评测执行器 argv[0] 为 python；60 秒无输出会终止进程，不能直接复制用于长时模型推理。

## S10
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/tasks/research_agent_task.py

读取对象：`ResearchAgentTask.from_config / prepare / dispatch`

已有配置绑定、类型匹配、awaitable 分发和用户运行任务冲突处理，可参考适配方式。

## S11
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/server/bootstrap/base.py

读取对象：`Bootstrap / UserTaskStateIndex`

deque、task_data、task_states、ongoing_tasks 位于内存；用户索引不是资源鉴权或 GPU 锁。

## S12
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/server/servlet/boot/runner_bootstrap.py

读取对象：`RunnerBootstrapBaseWeb.run / from_config`

真实路由均为 /runner/*；公共提交/查询/下载未在这里绑定认证依赖；新增配置必须由 from_config 显式接收。

## S13
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/server/server_init.py

读取对象：`dispatch / start_translator_client_proc`

既有 API + 本机 web_runner 子进程；配置读取队列与终态 TTL；内存删除使旧查询和下载失效；Worker 异常仅弹出一个 ongoing。

## S14
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/server/servlet/extract_file.py

读取对象：`extract_standard_file / extract_submit_file / extract_submit_mm_file`

旧上传使用评测目录并删除旧目录；部分解压 ZIP；不适合作为音乐任务音频上传接口。

## S15
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/server/model/result.py

读取对象：`TaskRunnerResponse / RunnerState`

已有 code/msg/data 外壳；状态为 str，而非受限枚举；JSON code 不自动等于 HTTP status。

## S16
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/load/serializable.py

读取对象：`Serializable / Config.extra`

Serializable 继承 Pydantic BaseModel；默认忽略 extra；新音乐请求必须主动禁止未知业务字段。

## S17
来源：https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/skills/yue2-music/SKILL.md

读取对象：`Choose the workflow / Generate / Cover / Edit`

原 Skill 包含生成、翻唱、转录、编辑和比较；辅助脚本相对 Skill 根目录执行；不能保证原歌手身份或原波形保留。

## S18
来源：https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/skills/yue2-music/references/models-and-setup.md

读取对象：`Models / Keep the environments separate`

模型职责、独立环境、依赖版本；SheetSage2 自动加载特定 MERT-v2-FullSong 父模型；普通生成不单独调用 MERT。

## S19
来源：https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/skills/yue2-music/scripts/run_yue2.py

读取对象：`request_data / main / run / decode`

辅助 CLI 为 generate/all-modes/plan/decode；请求字段与 ABC 互斥、cot 覆盖规则；退出码 1 需结合 run.json 区分失败和需复核。

## S20
来源：https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/src/yue2/protocol.py

读取对象：`SongRequest / guidance`

style、lyrics 必填字符串；cot full/melody/off；seed 默认831001、整数[0,2**63)；cfg_scale 有限[0,20]。

## S21
来源：https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/src/yue2/pipeline.py

读取对象：`YuE2Pipeline.from_pretrained / SongResult.save_artifacts`

加载主模型与 VAE；生成原生 audio.flac、request/config/result、tokens 与 latent；保存完整性清单。

## S22
来源：https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/src/yue2/storage.py

读取对象：`resolve_model / model_identity / verify_result`

现存目录直接解析；不存在的绝对路径报错；Hub ID 才 snapshot_download；校验manifest、相对产物路径、大小与哈希。

## S23
来源：https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/pyproject.toml

读取对象：`project / dependencies`

yue2-infer 0.1.6；torch2.10.0、transformers4.57.6、numpy2.2.6。

## S24
来源：https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/skills/yue2-music/assets/prompt.json

读取对象：`request example`

对象格式；示例含 id、style、lyrics、cot、seed。

## S25
来源：https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/skills/yue2-music/scripts/transcribe.py

读取对象：`main / run`

audio 位置参数；--task full/melody-full/melody-vocal；支持 --base-model、--offline；无可用 ABC 则失败。

## S26
来源：https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/skills/yue2-music/scripts/common.py

读取对象：`fresh_directory`

mkdir(parents=True, exist_ok=False)：--output 对应的目录不得预先创建。

## S27
来源：https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/skills/yue2-music/scripts/abc_tools.py

读取对象：`main (read 280–end)`

inspect / strip-chords / compare；compare 不一致退出1；strip-chords 不允许覆盖原稿。

## S28
来源：https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/backend/services/claude_plugin/workspace_packer.py

读取对象：`load_deck_plugin_refs / pack_workspace_plugins`

按 Deck 启用引用装包，写 .ink/launch-manifest.json；已建工作区冻结插件版本。

## S29
来源：https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/backend/libs/claude_agent_kit/server/plugin_launcher.py

读取对象：`read_workspace_launch_manifest / apply_plugin_launch_options`

校验插件摘要，设置 SDK plugins，最终为 --plugin-dir；仅创建 SKILL.md 不构成接入。

## S30
来源：https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/backend/claude_agent/service.py

读取对象：`pack_workspace_plugins callsite`

服务层确有 workspace_packer 调用；本文件仅检索调用点，未宣称通读全部内容。

## S31
来源：https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/backend/claude_agent/thread_factory.py

读取对象：`ClaudeAgentThreadFactory / run_streaming`

现有 Thread、EventBus 与会话生命周期可复用；SSE 断开与模型服务任务不应耦合。

## S32
来源：https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/backend/routers/workspace.py

读取对象：`_require_workspace_auth / _require_owned_workspace_thread / download_workspace_file`

下载要求 bearer、Thread ownership、Workspace Mode、受控路径与既有工作区；不需要新音频回填 API。

## S33
来源：https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/frontend/app/_dream/components/chat/workspaceFileAccess.ts

读取对象：`fetchWorkspaceFile`

使用 bearer 读取 /api/workspace/files/content 或 download；凭据不在 Markdown URL 中。

## S34
来源：https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/frontend/app/_dream/components/chat/WorkspaceFileReference.tsx

读取对象：`WorkspaceFileLink / WorkspaceImage`

有图片和 Markdown 预览、二进制下载；已读分支中无音频播放器，需要最小前端扩展。

## S35
来源：https://github.com/glide-the/RVC-Speakers/blob/f34904775fb74c450d1bcf300ecc1332a8890895/src/bases/speakers/start/core.py

读取对象：`Speaker / WebSpeaker`

与现服务配置、prepare/dispatch/progress模式同源相似；旧监听顺序执行，不能用它覆盖新版并发实现。

## S36
来源：https://github.com/glide-the/RVC-Speakers/blob/f34904775fb74c450d1bcf300ecc1332a8890895/src/components/speakers/tasks/vits_voice_task.py

读取对象：`VitsVoiceTask.dispatch`

已有 VITS→RVC 多阶段范式，直接在进程内交接音频数组；不能把此方式用于依赖冲突的 YuE/SheetSage2。

## S37
来源：https://github.com/glide-the/RVC-Speakers/blob/f34904775fb74c450d1bcf300ecc1332a8890895/README.md

读取对象：`model layout`

/media/checkpoint 来自该历史项目说明；本次不修改其无关历史文档。

## S38
来源：https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/processors/research_agent_processor.py

读取对象：`ResearchAgentProcessor.__call__ / from_config`

研究 Agent 在主进程内执行；未配置 environment 应保留此行为，不统一改为子进程。

## S39
来源：https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/backend/libs/claude_agent_kit/server/agent_runner.py

读取对象：`apply_plugin_launch_options / runtime guards`

插件加载发生在真实 SDK 选项边界；网络和写路径策略不能通过 Skill 声明跳过。

## W01
来源：https://code.claude.com/docs/en/plugins

读取对象：`官方页面/元数据`

官方插件目录与 Skill 加载约定。

## W02
来源：https://code.claude.com/docs/en/plugins-reference

读取对象：`官方页面/元数据`

官方插件 manifest 与 CLI 引用说明。

## G01
来源：https://api.github.com/repos/glide-the/agent-sandbox/pulls/11

读取对象：`官方页面/元数据`

本轮GitHub.get_pr_info确认merged=true，head sqlagent，base main，merge SHA与合并时间。

## G02
来源：https://api.github.com/repos/glide-the/agent-sandbox/branches/main

读取对象：`官方页面/元数据`

本轮GitHub.fetch确认当前main为8eb568…，parents包含PR11 head。
