# v1.2 接口收敛修订交付

**当前版本：1.2；仅文档、示例与静态校验，业务代码、GPU及IM联调未执行。**
新增通用 POST /runner/upload；输出沿用 GET /runner/result 与 GET /runner/result_source，按 task_id + result_source_name 取文件。第7节独立为 [07_Claude_plugin_Skill与IM接入设计.md](07_Claude_plugin_Skill与IM接入设计.md)；新增 [09_通用上传与任务输出资源契约修订.md](09_通用上传与任务输出资源契约修订.md)。模型Task/环境映射保留v1.1。
当前校验见 evidence/revision-checks.json，文件清单见 delivery-manifest.json。下方v1.0/v1.1记录为历史交付说明，其文件数量和校验数据不代表本版。

---

# YuE_IM_design_delivery

这是**设计交付包，不是已实现/已部署的业务系统或可安装插件**。

阅读 [交付清单](00_交付清单与阅读说明.md)、[完整设计稿](01_技术设计稿.md) 或离线 `阅读版.html`。实现位置、验证命令和审查分别见02、03、04。`diagrams`提供三份Mermaid源码。

解压后运行 `python tools/verify_delivery.py` 检查本包SHA256；此命令不进行GPU、服务或IM测试。

## v1.1 修订

每个独立执行模型固定绑定environment、preprocess和Task。当前注册yue2_task与sheetsage2_task；旧统一Task设计已被替换。详见08_模型环境与任务绑定修订.md。原v1.0 ZIP不覆盖。此包仍是设计文档，未包含已实现或已部署模型服务。
