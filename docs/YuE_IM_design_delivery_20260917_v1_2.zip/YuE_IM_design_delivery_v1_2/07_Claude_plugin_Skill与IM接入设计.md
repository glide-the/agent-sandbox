# Claude plugin Skill 与 IM 接入设计（独立文档）

Notion 独立页：https://app.notion.com/p/3de30b7547c3811d9548e8aa10f1587f

**版本：1.2｜范围：文档设计，不生成或修改插件业务代码。**

本文件独立承载原技术设计稿第7节；与主设计的接口及按模型划分的 Task 保持一致。模型部署和服务改造完成验证后再依据本文实施插件，不将文档当作可安装发行包。固定源码引用见文末及 evidence/sources.md。

## 接口与任务前提

只有 `/runner/upload` 是拟新增的公开资源接口。Skill 使用 POST /runner/upload 上传音频/ABC，取得 asset_id、sha256、size_bytes；再调用既有 POST /runner/submit。通过 GET /runner/result 查询 task_id 和资源清单，以 task_id + 清单给出的 result_source_name 调用 GET /runner/result_source。没有 publish-retry 动作或独立输出资源接口。

`yue2_task → yue2_processor → /root/yue-env`；`sheetsage2_task → sheetsage2_processor → /root/sheetsage2-env`。模型环境由服务端配置固定，Skill不把 environment、Processor或服务器输出路径放进请求。资源上传按认证 user_id 隔离，不能用用户参数替代授权。

## 1 插件最小结构与触发

拟部署插件如下；本交付包提供的是设计，不是假装已经可安装的插件发行包：

```text
im-yue-music/
  .claude-plugin/plugin.json
  skills/yue-music-service/SKILL.md
  skills/yue-music-service/scripts/music_service.py
  skills/yue-music-service/references/service-contract.md
```

manifest使用name/version/description；skills与.claude-plugin平级，不能把skills放进manifest目录。官方目录约定只解决Claude插件格式，不代表IM自动安装。[W01][W02]

Skill触发生成、转录、翻唱、改谱、改词、模式对比、已有task查询与产物获取；明确不支持声纹克隆、局部音频修补和上游没有的参数。客户端只需HTTP/文件处理，不加载torch/transformers，不SSH、不安装模型。ABC写作与音乐约束由Agent处理；检查/模型执行通过服务白名单动作完成。

## 2 真实IM加载与权限

按IM已有安装流程形成ready且digest固定的制品→加入Deck启用引用→新Thread首次相关执行pack_workspace_plugins→写工作区launch-manifest→plugin_launcher复核摘要→SDK plugins生成--plugin-dir→Skill可被调用。现有工作区冻结版本，不在运行中手写或改动`.ink/launch-manifest.json`；安装后验证使用新Thread或系统支持的受控重建流程。[S28][S29][S30]

在服务端最终运行环境组装处注入拟议`IM_YUE_SERVICE_URL`、该用户`IM_YUE_SERVICE_TOKEN`。服务域名需通过现有网络策略；客户端只能写当前工作区允许目录。Skill本身不能更改宿主网络/写入权限或跳过确认。[S39]

## 3 有限查询与恢复

客户端拟提供upload/submit/status/fetch，业务workflow由Skill组织。每5秒查询、单次等待最多60秒、或12次后退出（策略值，不是模型上限）；遇到end/error立即退出。保存workflow_id、各阶段task_name/task_id、Idempotency-Key、输入摘要和最后状态到`files/music/<workflow_id>/workflow.json`，不保存token。60秒结束不取消远端任务，也不无限占用Agent回合。

用户再次查询时恢复同一task。要继续翻唱则先确认转录终态及ABC检查，再提交生成阶段并保存新的请求键。没有已实现的自动通知就不承诺任务完成后主动弹出消息；SSE连接状态也不代表远端GPU任务状态。[S31]

## 4 完整用户场景

“用这份歌词写一首钢琴流行歌”：Skill整理style/lyrics/cot/seed→展示实际将用的请求摘要→通过 POST /runner/submit 提交取得task_id→展示真实排队/运行阶段→下载audio.flac与request/score等实际产物到当前files/music目录→返回workspace引用。下载失败只提示重新获取；OOM不缩短请求或降采样设置。

“把上传歌曲改成这个风格”：POST /runner/upload 上传音频→transcribe(melody-full)→检查ABC、warnings→若需修正则把问题和乐谱返回Agent/用户→generate(cot=melody, abc_source=已检查乐谱)→下载新音频与转录/生成来源记录。保留原唱身份不在此能力承诺内。

“保留主旋律，换和弦和歌词”：取得原始full计划并冻结→Agent另写修改稿→inspect与compare指定应保留的voice/tempo约束→检查通过或获得明确允许的变化记录→提交修改后的ABC+新歌词再生成→对照原谱、修改稿及两版音频。旧latent重解码不能替代此过程。[S17][S19][S27]

## 5 音频展示与资源关联

客户端在IM Agent所在运行环境下载文件，不需把AutoDL路径传给浏览器。返回示例URI形态`workspace://files/music/<workflow_id>/<task_id>/audio.flac`；由现有前端携带当前Thread与bearer调用workspace接口。下载与content路由已有主体和路径检查；不能把裸HTTP公开地址视为有权限。[S32][S33]

拟扩展WorkspaceFileReference中的音频分支：复用fetchWorkspaceFile取得blob、验证audio MIME、创建对象URL用于audio controls、卸载时revoke；失败保留显式下载。浏览器FLAC支持要实测，必要时显式提供WAV交付副本，不更改原始结果，也不凭扩展名保证播放。当前下载路由会读取整个文件到内存，第一版沿用且测试峰值占用；大文件播放出现实际瓶颈再扩为流式/Range，不现在新建媒体平台。[S32][S34]

此方案完成的是Thread工作区文件关联，不自动写入Editor文档、不自动加入长期Memory。需要文档引用时沿IM现有Editor操作与确认流程，作为独立用户动作。

## 下载与失败判定补充

客户端从真实清单选择 result_source_name，名称在任务内唯一，不发明一个独立资源ID。已生成文件只重新读取；失败的 GET 不触发模型重跑。服务端尚未完成文件登记时展示实际失败状态，GET保持只读，用户不承担触发“发布”的步骤。

## 文档验收

本文应覆盖插件载入、用户凭据与权限、两类Task、四类业务流程、有限查询、原始/修订文件关联及IM资源获取；文档、请求示例和时序图的接口名称一致。上述内容已成文不代表插件已经创建、安装或通过IM联调。

<!-- 固定源码/官方资料引用 -->
[S01]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox.yaml
[S02]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/processors/__init__.py
[S03]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/tasks/__init__.py
[S04]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/server/model/flow_data.py
[S05]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/server/servlet/runner.py
[S06]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/start/core.py
[S07]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/tasks/base_task.py
[S08]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/processors/base_processor.py
[S09]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/processors/sanbox_started.py
[S10]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/tasks/research_agent_task.py
[S11]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/server/bootstrap/base.py
[S12]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/server/servlet/boot/runner_bootstrap.py
[S13]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/server/server_init.py
[S14]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/server/servlet/extract_file.py
[S15]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/server/model/result.py
[S16]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/load/serializable.py
[S17]: https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/skills/yue2-music/SKILL.md
[S18]: https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/skills/yue2-music/references/models-and-setup.md
[S19]: https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/skills/yue2-music/scripts/run_yue2.py
[S20]: https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/src/yue2/protocol.py
[S21]: https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/src/yue2/pipeline.py
[S22]: https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/src/yue2/storage.py
[S23]: https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/pyproject.toml
[S24]: https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/skills/yue2-music/assets/prompt.json
[S25]: https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/skills/yue2-music/scripts/transcribe.py
[S26]: https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/skills/yue2-music/scripts/common.py
[S27]: https://github.com/multimodal-art-projection/YuE/blob/bd90e4ccae671d869b3ecaca6d7e893927d29442/skills/yue2-music/scripts/abc_tools.py
[S28]: https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/backend/services/claude_plugin/workspace_packer.py
[S29]: https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/backend/libs/claude_agent_kit/server/plugin_launcher.py
[S30]: https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/backend/claude_agent/service.py
[S31]: https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/backend/claude_agent/thread_factory.py
[S32]: https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/backend/routers/workspace.py
[S33]: https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/frontend/app/_dream/components/chat/workspaceFileAccess.ts
[S34]: https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/frontend/app/_dream/components/chat/WorkspaceFileReference.tsx
[S35]: https://github.com/glide-the/RVC-Speakers/blob/f34904775fb74c450d1bcf300ecc1332a8890895/src/bases/speakers/start/core.py
[S36]: https://github.com/glide-the/RVC-Speakers/blob/f34904775fb74c450d1bcf300ecc1332a8890895/src/components/speakers/tasks/vits_voice_task.py
[S37]: https://github.com/glide-the/RVC-Speakers/blob/f34904775fb74c450d1bcf300ecc1332a8890895/README.md
[S38]: https://github.com/glide-the/agent-sandbox/blob/8eb568e4fe3b333a31469a60bff2693493a520c8/sandbox/processors/research_agent_processor.py
[S39]: https://github.com/glide-the/im-dream/blob/a40486e220853d3044eb524bc7b2efa59e18da1a/backend/libs/claude_agent_kit/server/agent_runner.py
[W01]: https://code.claude.com/docs/en/plugins
[W02]: https://code.claude.com/docs/en/plugins-reference
[G01]: https://api.github.com/repos/glide-the/agent-sandbox/pulls/11
[G02]: https://api.github.com/repos/glide-the/agent-sandbox/branches/main
