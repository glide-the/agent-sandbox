# YuE任务服务与Claude plugin Skill设计 v1.3

先读[交付清单](00_交付清单与阅读说明.md)，服务端设计见[技术稿](01_技术设计稿.md)，封装说明见[独立Skill文档](07_Claude_plugin_Skill封装设计.md)。

业务步骤保持原yue2-music Skill，模型执行由本地调用改为agent-sandbox任务调用。仅设计交付，未实现业务代码或执行模型验收。校验记录见evidence/revision-checks.json。
